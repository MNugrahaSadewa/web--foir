// Fungsi untuk merender keranjang
function renderCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartTableBody = document.getElementById("cart-table-body");
    const cartTotalElement = document.getElementById("cart-total");

    // Kosongkan tabel terlebih dahulu
    cartTableBody.innerHTML = "";

    if (cart.length === 0) {
        cartTableBody.innerHTML = `<tr><td colspan="7" class="text-center text-muted">Your cart is empty.</td></tr>`;
        cartTotalElement.textContent = "Total: Rp 0";
        return;
    }

    let total = 0;

    cart.forEach((item, index) => {
        const row = document.createElement("tr");
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.color}</td>
            <td>${item.size}</td>
            <td>Rp ${formatRupiah(item.price)}</td>
            <td>
                <input type="number" class="form-control quantity-input" value="${item.quantity}" min="1" data-index="${index}">
            </td>
            <td>Rp ${formatRupiah(itemTotal)}</td>
            <td>
                <button class="btn btn-danger btn-sm" onclick="removeFromCart(${index})">Remove</button>
            </td>
        `;

        cartTableBody.appendChild(row);
    });

    cartTotalElement.textContent = `Total: Rp ${formatRupiah(total)}`;

    // Tambahkan event listener untuk quantity
    document.querySelectorAll(".quantity-input").forEach((input) => {
        input.addEventListener("change", (event) => {
            const index = event.target.getAttribute("data-index");
            const newQuantity = parseInt(event.target.value);

            if (newQuantity > 0) {
                updateQuantity(index, newQuantity);
            } else {
                alert("Quantity must be at least 1.");
                event.target.value = 1; // Reset ke 1 jika input tidak valid
            }
        });
    });
}

// Fungsi untuk mengubah jumlah quantity
function updateQuantity(index, newQuantity) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart[index].quantity = newQuantity;
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart(); // Render ulang keranjang
}

// Fungsi untuk menghapus item dari keranjang
function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1); // Hapus item berdasarkan index
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart(); // Render ulang keranjang
}

// Fungsi untuk memformat angka ke format Rupiah
function formatRupiah(angka) {
    return angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// Saat halaman dimuat, tampilkan keranjang
document.addEventListener("DOMContentLoaded", renderCart);

document.getElementById("checkout-button").addEventListener("click", function(e) {
    e.preventDefault();
    console.log("Proceed to Checkout button clicked"); // Verifikasi jika event listener bekerja
    window.location.href = "checkout.html";
});

