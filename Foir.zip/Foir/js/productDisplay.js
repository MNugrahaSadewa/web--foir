// Fungsi untuk mendapatkan ID produk dari URL
function getProductIdFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return parseInt(urlParams.get("id")) || null; // Mengambil parameter ?id dari URL atau null jika tidak ditemukan
  }
  
  // Fungsi untuk menampilkan produk berdasarkan ID
  function displayProduct(productId) {
    // Validasi jika produk tidak ditemukan
    if (typeof products === "undefined" || !Array.isArray(products)) {
      console.error("Product data is not defined or is not an array.");
      document.querySelector(".s_product_text").innerHTML = "<p>Product data is unavailable.</p>";
      return;
    }
  
    const product = products.find((p) => p.id === productId); // Cari produk berdasarkan ID
  
    if (!product) {
      document.querySelector(".s_product_text").innerHTML = "<p>Product not found.</p>";
      return;
    }
  
    // Update konten produk
    document.getElementById("product-name").textContent = product.name || "Unknown Product";
    document.getElementById("product-price").textContent = `Rp ${product.price || 0}`;
    document.getElementById("product-category").textContent = product.category || "Unknown Category";
    document.getElementById("product-availability").textContent = product.availability || "Not Available";
    document.getElementById("product-description").textContent = product.description || "No description available.";
  
    // Update gambar produk
    const carousel = document.getElementById("product-carousel");
    carousel.innerHTML = ""; // Bersihkan carousel sebelum mengisi ulang
    if (product.images && product.images.length > 0) {
      product.images.forEach((image) => {
        const div = document.createElement("div");
        div.className = "single-prd-item";
        div.innerHTML = `<img class="img-fluid" src="${image}" alt="${product.name}">`;
        carousel.appendChild(div);
      });
    } else {
      const noImage = document.createElement("div");
      noImage.className = "single-prd-item";
      noImage.innerHTML = `<p>No images available</p>`;
      carousel.appendChild(noImage);
    }
  
    // Inisialisasi carousel jika OwlCarousel tersedia
    if (typeof $ !== "undefined" && $(".s_Product_carousel").owlCarousel) {
      $(".s_Product_carousel").owlCarousel({
        items: 1,
        autoplay: false,
        autoplayTimeout: 5000,
        loop: true,
        nav: true, // Mengaktifkan tombol navigasi
        navText: false, // Ikon navigasi
        dots: true, // Menampilkan indikator titik
      });
    } else {
      console.warn("OwlCarousel is not loaded or jQuery is missing.");
    }
  
    // Update warna di dropdown
    const colorSelect = document.getElementById("colors");
    colorSelect.innerHTML = ""; // Bersihkan dropdown sebelum mengisi ulang
    if (product.colors && product.colors.length > 0) {
      product.colors.forEach((color) => {
        const option = document.createElement("option");
        option.value = color.toLowerCase();
        option.textContent = color;
        colorSelect.appendChild(option);
      });
    } else {
      const noOption = document.createElement("option");
      noOption.textContent = "No colors available";
      noOption.disabled = true;
      colorSelect.appendChild(noOption);
    }
  
    // Update ukuran di dropdown
    const sizeSelect = document.getElementById("sizes");
    sizeSelect.innerHTML = ""; // Bersihkan dropdown sebelum mengisi ulang
    if (product.sizes && product.sizes.length > 0) {
      product.sizes.forEach((size) => {
        const option = document.createElement("option");
        option.value = size.toLowerCase();
        option.textContent = size;
        sizeSelect.appendChild(option);
      });
    } else {
      const noOption = document.createElement("option");
      noOption.textContent = "No sizes available";
      noOption.disabled = true;
      sizeSelect.appendChild(noOption);
    }
  }
  
  // Ambil ID produk dari URL
  const productId = getProductIdFromURL();
  
  // Tampilkan produk jika ID valid
  if (!isNaN(productId) && productId !== null) {
    displayProduct(productId);
  } else {
    console.error("Invalid product ID in URL.");
    document.querySelector(".s_product_text").innerHTML = "<p>Invalid product ID.</p>";
  }
  


 // Fungsi untuk menambahkan produk ke keranjang
function addToCart() {
    // Ambil informasi produk dari halaman DOM saat fungsi dipanggil
    const productName = document.getElementById("product-name").textContent;
    const productPrice = parseFloat(document.getElementById("product-price").textContent.replace(/[^0-9]/g, ""));
    const productCategory = document.getElementById("product-category").textContent;
    const selectedColor = document.getElementById("colors").value;
    const selectedSize = document.getElementById("sizes").value;
    const quantityInput = document.getElementById("quantity");
    const quantity = parseInt(quantityInput.value);

    // Validasi input
    if (!selectedColor || !selectedSize || quantity <= 0) {
        alert("Please select a valid color, size, and quantity.");
        return;
    }

    // Ambil keranjang dari localStorage (atau buat array kosong jika belum ada)
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Cek apakah produk dengan warna dan ukuran yang sama sudah ada di keranjang
    const existingProductIndex = cart.findIndex(
        (item) => item.name === productName && item.color === selectedColor && item.size === selectedSize
    );

    if (existingProductIndex > -1) {
        // Jika produk sudah ada, tambahkan kuantitas
        cart[existingProductIndex].quantity += quantity;
    } else {
        // Jika produk belum ada, tambahkan sebagai item baru
        const newProduct = {
            name: productName,
            price: productPrice,
            category: productCategory,
            color: selectedColor,
            size: selectedSize,
            quantity: quantity,
        };
        cart.push(newProduct);
    }

    // Simpan keranjang ke localStorage
    localStorage.setItem("cart", JSON.stringify(cart));

    // Redirect ke halaman cart.html
    window.location.href = "cart.html";
}

// Tambahkan event listener ke tombol Add to Cart
const addToCartButton = document.querySelector(".add-to-cart");
addToCartButton.addEventListener("click", (e) => {
    e.preventDefault(); // Mencegah aksi default tombol
    addToCart();
});

