const API_BASE_URL = "https://alamat.thecloudalert.com/api/";

// Ambil elemen form dan elemen lainnya
const checkoutForm = document.getElementById("checkout-form");
const provinceSelect = document.getElementById("province");
const citySelect = document.getElementById("city");
const districtSelect = document.getElementById("district");
const subdistrictSelect = document.getElementById("subdistrict");

// Fungsi untuk menangani respons API dan kesalahan
async function fetchData(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch data");
        const data = await response.json();
        if (data.status !== 200) throw new Error(data.message || "API error");
        return data.result;
    } catch (error) {
        console.error("Error:", error.message);
        alert("Terjadi kesalahan saat memuat data. Silakan coba lagi.");
        return [];
    }
}

// Fungsi untuk mengambil daftar provinsi
async function fetchProvinces() {
    const provinces = await fetchData(`${API_BASE_URL}provinsi/get/`);
    provinceSelect.innerHTML = '<option value="" selected disabled>Pilih Provinsi</option>';
    provinces.forEach((province) => {
        const option = document.createElement("option");
        option.value = province.id;
        option.textContent = province.text;
        provinceSelect.appendChild(option);
    });
}

// Fungsi untuk mengambil daftar kota/kabupaten berdasarkan provinsi
async function fetchCities(provinceId) {
    citySelect.innerHTML = '<option value="" selected disabled>Pilih Kota/Kabupaten</option>';
    districtSelect.innerHTML = '<option value="" selected disabled>Pilih Kecamatan</option>';
    subdistrictSelect.innerHTML = '<option value="" selected disabled>Pilih Kelurahan</option>';

    const cities = await fetchData(`${API_BASE_URL}kabkota/get/?d_provinsi_id=${provinceId}`);
    cities.forEach((city) => {
        const option = document.createElement("option");
        option.value = city.id;
        option.textContent = city.text;
        citySelect.appendChild(option);
    });
}

// Fungsi untuk mengambil daftar kecamatan berdasarkan kota/kabupaten
async function fetchDistricts(cityId) {
    districtSelect.innerHTML = '<option value="" selected disabled>Pilih Kecamatan</option>';
    subdistrictSelect.innerHTML = '<option value="" selected disabled>Pilih Kelurahan</option>';

    const districts = await fetchData(`${API_BASE_URL}kecamatan/get/?d_kabkota_id=${cityId}`);
    districts.forEach((district) => {
        const option = document.createElement("option");
        option.value = district.id;
        option.textContent = district.text;
        districtSelect.appendChild(option);
    });
}

// Fungsi untuk mengambil daftar kelurahan berdasarkan kecamatan
async function fetchSubdistricts(districtId) {
    subdistrictSelect.innerHTML = '<option value="" selected disabled>Pilih Kelurahan</option>';

    const subdistricts = await fetchData(`${API_BASE_URL}kelurahan/get/?d_kecamatan_id=${districtId}`);
    subdistricts.forEach((subdistrict) => {
        const option = document.createElement("option");
        option.value = subdistrict.id;
        option.textContent = subdistrict.text;
        subdistrictSelect.appendChild(option);
    });
}

// Event listener untuk provinsi
provinceSelect.addEventListener("change", (e) => {
    const provinceId = e.target.value;
    fetchCities(provinceId);
});

// Event listener untuk kota/kabupaten
citySelect.addEventListener("change", (e) => {
    const cityId = e.target.value;
    fetchDistricts(cityId);
});

// Event listener untuk kecamatan
districtSelect.addEventListener("change", (e) => {
    const districtId = e.target.value;
    fetchSubdistricts(districtId);
});

// Fungsi untuk format Rupiah
function formatRupiah(number) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
        minimumFractionDigits: 0,
    }).format(number);
}

// Fungsi untuk menampilkan detail pesanan di tabel
function displayCheckoutDetails() {
    const checkoutDetails = document.getElementById("checkout-details");
    const totalPriceElement = document.getElementById("total-price");

    // Ambil data keranjang dari localStorage
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Jika keranjang kosong, tampilkan pesan
    if (cart.length === 0) {
        checkoutDetails.innerHTML = `
            <tr>
                <td colspan="6" class="text-center">Keranjang Anda kosong.</td>
            </tr>
        `;
        totalPriceElement.textContent = "Rp 0";
        return;
    }

    // Variabel untuk menghitung total harga
    let totalPrice = 0;

    // Iterasi setiap item dalam keranjang
    cart.forEach((item) => {
        const itemTotal = item.price * item.quantity;
        totalPrice += itemTotal;

        // Tambahkan baris untuk setiap item
        const row = `
            <tr>
                <td>${item.name}</td>
                <td>${item.color}</td>
                <td>${item.size}</td>
                <td>${formatRupiah(item.price)}</td>
                <td>${item.quantity}</td>
                <td>${formatRupiah(itemTotal)}</td>
            </tr>
        `;
        checkoutDetails.innerHTML += row;
    });

    // Tampilkan total harga
    totalPriceElement.textContent = formatRupiah(totalPrice);
}

function sendToWhatsApp(e) {
    e.preventDefault();

    // Ambil data dari form
    const name = document.getElementById("name").value;
    const whatsapp = document.getElementById("whatsapp").value;
    const address = document.getElementById("address").value;
    const province = provinceSelect.options[provinceSelect.selectedIndex].text;
    const city = citySelect.options[citySelect.selectedIndex].text;
    const district = districtSelect.options[districtSelect.selectedIndex].text;
    const subdistrict = subdistrictSelect.options[subdistrictSelect.selectedIndex].text;
    // Ambil metode pembayaran yang dipilih
    const paymentMethod = document.querySelector('input[name="payment-method"]:checked');
    if (!paymentMethod) {
        alert("Mohon pilih metode pembayaran.");
        return;
    }
    const paymentMethodText = paymentMethod.nextElementSibling.querySelector("strong").textContent;


    // Ambil data keranjang dari localStorage
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    if (!name || !whatsapp || !address || !province || !city || !district || !subdistrict) {
        alert("Mohon lengkapi semua data sebelum melanjutkan.");
        return;
    }

    if (cart.length === 0) {
        alert("Keranjang Anda kosong.");
        return;
    }

    // Format pesan WhatsApp
    let message = `*Pesanan Baru*\n\n`;
    message += `*Nama:* ${name}\n`;
    message += `*No. WhatsApp:* ${whatsapp}\n`;
    message += `*Alamat:* ${address}, Kelurahan ${subdistrict}, Kecamatan ${district}, ${city}, ${province}\n\n`;
    message += `*Metode Pembayaran:* ${paymentMethodText}\n\n`;
    message += `*Detail Pesanan:*\n`;

    cart.forEach((item, index) => {
        message += `${index + 1}. ${item.name} - ${item.color} - ${item.size} x${item.quantity} = ${formatRupiah(item.price * item.quantity)}\n`;
    });

    const totalPrice = cart.reduce((total, item) => total + item.price * item.quantity, 0);
    message += `\n*Total Harga:* ${formatRupiah(totalPrice)}\n\n`;
    message += `Terima kasih atas pesanan Anda!`;

    // Ganti dengan nomor WhatsApp konveksi
    const konveksiWhatsApp = "6281318261945"; // Ganti dengan nomor WhatsApp konveksi Anda
    const whatsappURL = `https://web.whatsapp.com/send?phone=${konveksiWhatsApp}&text=${encodeURIComponent(message)}`;
    
    // Pastikan window open membuka URL dengan benar
    window.open(whatsappURL, "_blank");
}



// Panggil fungsi untuk menampilkan detail pesanan saat halaman dimuat
displayCheckoutDetails();

// Panggil fungsi untuk memuat data provinsi saat halaman dimuat
fetchProvinces();

// Tambahkan event listener ke form untuk mengirim data ke WhatsApp
checkoutForm.addEventListener("submit", sendToWhatsApp);
