const products = [
    {
        "id": 1,
        "name": "Kaos Sablon",
        "price": "100.000",
        "category": "Kaos",
        "availability": "In Stock",
        "description": "Kaos ini terbuat dari bahan cotton combed yang nyaman dan menyerap keringat. Dilengkapi dengan model leher O-neck dan jahitan pundak rantai yang kuat. Jahitan leher stik adem memberikan kenyamanan ekstra. Desainnya menggunakan sablon DTF yang menghasilkan warna tajam, awet, dan tahan lama. Cocok untuk dipakai sehari-hari.",
        "colors": ["Blueeee", "Black", "Red"],
        "sizes": ["Small", "Medium", "Large", "Extra Large"],
        "images": ["img/product/ps1.jpeg", "img/product/ps1.jpeg", "img/product/ps1.jpeg"]
      },
      {
        "id": 2,
        "name": "Kaos contoh",
        "price": "100.000",
        "category": "Kaos",
        "availability": "In Stock",
        "description": "Kaos ini terbuat dari bahan cotton combed yang nyaman dan menyerap keringat. Dilengkapi dengan model leher O-neck dan jahitan pundak rantai yang kuat. Jahitan leher stik adem memberikan kenyamanan ekstra. Desainnya menggunakan sablon DTF yang menghasilkan warna tajam, awet, dan tahan lama. Cocok untuk dipakai sehari-hari.",
        "colors": ["Blue", "Black", "Red"],
        "sizes": ["Small", "Medium", "Large", "Extra Large"],
        "images": ["img/product/ps1.jpeg", "img/product/ps1.jpeg", "img/product/ps1.jpeg"]
      },
      {
        "id": 3,
        "name": "Classic Black Jacket",
        "price": "199.99",
        "category": "Fashion",
        "availability": "In Stock",
        "description": "Timeless black jacket for every season.",
        "colors": ["Blue", "Black", "Red"],
        "sizes": ["Small", "Medium", "Large", "Extra Large"],
        "images": ["img/product/ps1.jpeg", "img/product/ps1.jpeg"]
      },
      {
        "id": 4,
        "name": "Moderndd White Shirt",
        "price": "100",
        "category": "Fashion",
        "availability": "Limited Stock",
        "description": "A stylish white shirt made for modern fashion enthusiasts.",
        "colors": ["Blue", "Black", "Red"],
        "sizes": ["Small", "Medium", "Large", "Extra Large"],
        "images": ["img/product/ps1.jpeg", "img/product/ps1.jpeg", "img/product/ps1.jpeg"]
      }
];